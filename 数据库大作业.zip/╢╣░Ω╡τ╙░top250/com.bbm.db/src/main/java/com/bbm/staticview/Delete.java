package com.bbm.staticview;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.bbm.db.stocksinvestDao;

public class Delete extends JFrame {
	
	private JPanel panel,moviePanel,btnPanel;
	private JLabel cname;
	private JTextField cnameTex;
	 JComboBox cmbMovieType;//组合框
	 private JButton btndel,btnReset,btnExit;
	 
	 
	public Delete() {
		
		setTitle("删除");
		  setSize(400,200);//框的长宽
		 setLocationRelativeTo(null);
	      panel=new JPanel(new BorderLayout());
	      setContentPane(panel);
	      //影片面板的信息
	      GridLayout grid1=new GridLayout(3,3);//网格布局（采用指定的行数列数）
	      grid1.setHgap(20);//组件之间的水平间距
	      grid1.setVgap(20);//组件之间的垂直间距
	      moviePanel=new JPanel(grid1);
	      cname=new JLabel("企业名称：");
	      cnameTex=new JTextField(12);
	      moviePanel.add(cname);
	      moviePanel.add(cnameTex);
	      panel.add(moviePanel,BorderLayout.CENTER);
	      btnPanel=new JPanel();
	      btndel=new JButton("删除");
	      btnReset=new JButton("重置");
	      btnExit=new JButton("退出");
	      btnPanel.add(btndel);
	      btnPanel.add(btnReset);
	      btnPanel.add(btnExit);
	      panel.add(btnPanel,BorderLayout.SOUTH);       
	      
	      setVisible(true);   
	     
	
	
	btndel.addActionListener(new ActionListener() {
		
		
		private void closeThis() {
			// TODO Auto-generated method stub
			
		}
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			if(e.getActionCommand().equals("删除")) {
			new stocksinvestDao();
			 final String name=cnameTex.getText();
			int r=stocksinvestDao.delete(name);
			System.out.print("名字为 "+name+" 的记录已经被删除！");
			}
			//进入到新界面 UIzhuec
			closeThis();
	}
	});

	btnExit.addActionListener(new ActionListener() {
		 public void actionPerformed(ActionEvent e) {
	// TODO 自动生成的方法存根
			 if(e.getActionCommand().equals("退出")){
	   System.exit(0);
		         }
	  }
	 });}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Delete();

	}

}
