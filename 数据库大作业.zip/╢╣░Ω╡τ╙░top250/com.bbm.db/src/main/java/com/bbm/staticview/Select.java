package com.bbm.staticview;
import com.bbm.db.*;
import java.awt.Container;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Select extends JFrame{
	TextField t1;
	TextField t2;
	public Select() {
		setTitle("查询");
		 setSize(550, 370);
		 JPanel p1=new JPanel();
		//getContentPane().add(p1);
		JLabel j1=new JLabel("股票的编码：  " );
		JLabel j2=new JLabel("企业名称：  " );
		JLabel j3=new JLabel("评价：  " );
		TextField t1=new TextField(70);
		TextField t2=new TextField(70);
		TextField t3=new TextField(70);//长度
		JButton b=new JButton("查询");
		JButton b1=new JButton("取消");
		ImageIcon img2 = new ImageIcon("E:\\qiuye\\123.jpg");
		//相对路径获取图片
		JLabel imgLabel = new JLabel(img2); 
		//创建图片标签
		this.getLayeredPane().add(imgLabel, new Integer(Integer.MIN_VALUE));
		//为标签设置为容器最底层；getLayeredPane()作用是为容器添加深度，允许组件互相重叠；
		//Integer.MIN_VALUE最底层
		imgLabel.setBounds(0,0,img2.getIconWidth(), img2.getIconHeight());
		          Container p11=getContentPane();           
		//获取顶级容器
		       ((JPanel)p11).setOpaque(false);  
		       //设置透明以使底层背景图片显示
		       p11.setLayout(null);            
		p11.add(j2);
		j2.setBounds(50, 70, 70, 25);
		p11.add(t1);
		t1.setBounds(150, 70,100, 20);
		p11.add(j1);
		j1.setBounds(50, 150, 70, 25);
		p11.add(t2);
		t2.setBounds(150,150,100, 20);
		p11.add(j3);
		j3.setBounds(50,230,70, 25);
		p11.add(t3);
		t3.setBounds(150, 230,100, 20);
		p11.add(b);
		b.setBounds(400,140,90,25);
		b1.setBounds(400,170,90,25);
		setLocationRelativeTo(null);
		setVisible(true);
		final String url = "jdbc:mysql://localhost:3306/MOVIES";
		final String name=t2.getText();
		b.addActionListener(new ActionListener() {
			
			
			private void closeThis() {
				// TODO Auto-generated method stub
				
			}
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			if(e.getActionCommand().equals("查询")) {
				new stocksinvestDao();
				ResultSet r=stocksinvestDao.select(name);
				
				}
				
				closeThis();
				
				//进入到新界面 UIzhuec
			
		}
		});

		b1.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
		// TODO 自动生成的方法存根
				 if(e.getActionCommand().equals("取消")){
		   System.exit(0);
			         }
		  }
		 });}
		
		 public static void main(String[] args) {
		      new Select();

		   }
	}
