package com.bbm.db;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.bbm.model.stocksinvest;
public class stocksinvestDao{
	//根据企业名字删除股票
	public static int delete(String name) {
		// 先定义数据库连接，预处理
	      Connection connection = null;
	      PreparedStatement statement = null;
	      int ret = 0;
	 
	      try{
	          //1.获取到数据库连接
	          connection = Dao.getConnection();
	          //2.拼装sql语句
	          String sql="delete from stocksinvest where name= "+'\"'+name+'\"';
	          statement = connection.prepareStatement(sql);
	          ret = statement.executeUpdate();
	         
	      } catch (SQLException throwables) {
	          throwables.printStackTrace();
	      }finally {
	        Dao.close(null,statement,connection);
	      }
	      return ret;
		
	}
	//查询企业股票信息
	public static ResultSet select(String name) {
		// 先定义数据库连接，预处理
	      Connection connection = null;
	      PreparedStatement statement = null;
	      ResultSet ret = null;
		
	      // 定义一个list用于接受数据库查询到的内容
	      List<String> list = new ArrayList<String>();
	      try{
	          //1.获取到数据库连接
	          connection = Dao.getConnection();
	          //2.拼装sql语句
	          String sql="select * from stocksinvest where name = "+'"'+name+'"'
;
	          statement = connection.prepareStatement(sql);
	          ret = statement.executeQuery();
	          System.out.println("编号"+"\t"+"企业名字"+"\t"+"评价"+"\t"+"评价机构"+"\t"+"评价日期"+"\t"+"评价师");
	          while (ret.next()) {
	              // 将查询出的内容添加到list中，其中name为数据库中的字段名称
	        	  System.out.print(ret.getString(1) + "\t");
	        	  System.out.print(ret.getString(2) + "\t");
	        	  System.out.print(ret.getString(3) + "\t");
	        	  System.out.print(ret.getString(4) + "\t");
	        	  System.out.print(ret.getString(5) + "\t");
	        	  System.out.println();
	              list.add(ret.getString("name"));}
	      } catch (SQLException throwables) {
	          throwables.printStackTrace();
	      }finally {
	        Dao.close(null,statement,connection);
	      }
	      return ret;
		
	}
	
	//增加功能
	public static int add(stocksinvest s) {
		// 先定义数据库连接，预处理
	      Connection connection = null;
	      PreparedStatement statement = null;
	      int ret = 0;
	      try{
	          //1.获取到数据库连接
	          connection = Dao.getConnection();
	          //2.拼装sql语句
	          String sql="insert into stocksinvest(no,name,com,pla,date,an)"+"value('"+s.getRank()+"','"
	        		  +s.getChname()+"','"+s.getFoname()+"','"+s.getCommentGrade()+"','"
	        		  +s.getCommentsNum()+"','"+s.getIntroduction()+");";
	          statement = connection.prepareStatement(sql);
	          ret = statement.executeUpdate();
	      } catch (SQLException throwables) {
	          throwables.printStackTrace();
	      }finally {
	        Dao.close(null,statement,connection);
	      }
	      return ret;
	}
	//修改功能
	public static int update(stocksinvest s){
	     Connection connection = Dao.getConnection();
	     PreparedStatement statement = null;
	     ResultSet resultSet = null;
	     int ret = 0;
	     try{
	          //1.获取到数据库连接
	          connection = Dao.getConnection();
	          //2.拼装sql语句
	          String sql="update into stocksinvest set name='"+s.getChname()+"',com='"+s.getFoname()
	          +"',pla='"+s.getCommentGrade()+"',date='"
	        		  +s.getCommentsNum()+"',an='"+s.getIntroduction()+"'where no='"+s.getRank()+";";
	        		 
	          statement = connection.prepareStatement(sql);
	          ret = statement.executeUpdate();
	      } catch (SQLException throwables) {
	          throwables.printStackTrace();
	      }finally {
	        Dao.close(null,statement,connection);
	      }
	      return ret;
	}
}


	






