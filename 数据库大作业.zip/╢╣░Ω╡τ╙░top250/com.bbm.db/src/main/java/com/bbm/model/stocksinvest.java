package com.bbm.model;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
 
@Getter
@Setter
@ToString
public class stocksinvest {
 
 
	int rank;//no
	String chname;//name
	String foname;//com
	double commentGrade;//pla
	int commentsNum;//date
	String introduction;//an
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	public String getChname() {
		return chname;
	}
	public void setChname(String chname) {
		this.chname = chname;
	}
	public String getFoname() {
		return foname;
	}
	public void setFoname(String foname) {
		this.foname = foname;
	}
	public double getCommentGrade() {
		return commentGrade;
	}
	public void setCommentGrade(double commentGrade) {
		this.commentGrade = commentGrade;
	}
	public int getCommentsNum() {
		return commentsNum;
	}
	public void setCommentsNum(int commentsNum) {
		this.commentsNum = commentsNum;
	}
	public String getIntroduction() {
		return introduction;
	}
	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}

}
 


