package com.bbm.staticview;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.print.DocFlavor.URL;
import javax.swing.*;
public class Login extends JFrame {
   private JPanel myPanel;//面板
   private ImageIcon background;
   private JLabel labName,labPassword;//按钮
   private JTextField txtName;//用户名
   private JPasswordField txtPassword;
   private JButton btnConfirm,btnReset;//登录和重置
   private JLabel label;
    public Login(String name){
    	
      super(name);//框架类设标题
      setSize(250,150);
      setLocationRelativeTo(null);
      myPanel=new JPanel();
      setContentPane(myPanel);
      labName=new JLabel("用户名：");       
      labPassword=new JLabel("密   码：");
      txtName=new JTextField(12);
      txtPassword=new JPasswordField(12);
      txtPassword.setEchoChar('*');
      btnConfirm=new JButton("登录");
      btnReset=new JButton("重置");
      myPanel.add(labName);
      myPanel.add(txtName);
      myPanel.add(labPassword);
      myPanel.add(txtPassword);
      myPanel.add(btnConfirm);
      myPanel.add(btnReset);    

      setVisible(true);   
      
      try {
    		btnConfirm.addActionListener(new ActionListener() {
    				//给需要跳转的按钮加上监听。
    				
    				
    		
    				private void closeThis() {
    					// TODO Auto-generated method stub
    					
    				}
    				public void actionPerformed(ActionEvent e) {
    					// TODO Auto-generated method stub
    					closeThis();
    					new Main();
    					//进入到新界面 UIzhuec
    				}
    			
    			});
    	} catch (Exception e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}

     

        }
   public static void main(String[] args) {
      // TODO Auto-generated method stub
      new Login("登录");
      
   }
}
