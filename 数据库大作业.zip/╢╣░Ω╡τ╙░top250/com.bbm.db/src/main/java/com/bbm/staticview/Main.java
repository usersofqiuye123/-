package com.bbm.staticview;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Main extends JFrame {
	JButton b1;
	 JButton b2;
	 public Main(){
		 //创造一个新的界面
		 setSize(550,370);//设置窗口大小
		 Toolkit tk=getToolkit();
		 /*
		  *基本介绍
Toolkit是java中的抽象超类，
Toolkit 的子类被用于将各种组件绑定到特定本机工具包实现。
		  */
		 Dimension d1=tk.getScreenSize();
		 // dimension是Java的一个类，封装了一个构件的高度和宽度
		 //getSize()和setSize(Dimension size)。分别用来获得和设置方格的大小
		 int w=(int)d1.getWidth();
		 int h=(int)d1.getHeight();
		 setLocation(w/2-550/2, h/2-370/2);
		 setVisible(true);
		 setTitle("股票投资系统");//文字显示
		 //setIconImage(img1);
        ImageIcon img2 = new ImageIcon("./src/Bp/1	R-C.jpg");          //相对路径获取图片
		 JLabel imgLabel = new JLabel(img2);  //创建图片标签
		 
		 this.getLayeredPane().add(imgLabel, new Integer(Integer.MIN_VALUE));
//为标签设置为容器最底层；getLayeredPane()作用是为容器添加深度，允许组件互相重叠；
		 //Integer.MIN_VALUE最底层
		 imgLabel.setBounds(0,0,img2.getIconWidth(), img2.getIconHeight());
imgLabel.setBounds(0,0,img2.getIconWidth(), img2.getIconHeight());
Container cp=getContentPane();                           
//获取顶级容器
((JPanel)cp).setOpaque(false);          
//设置透明以使底层背景图片显示
cp.setLayout(null); 
JLabel imgLable=new JLabel();
JLabel j2=new JLabel("***欢迎登陆股票投资管理系统***");
JLabel j1=new JLabel("~~请在左侧做出选择~~");
JButton b1=new JButton("查询");
JButton b2=new JButton("取消");
JButton b3=new JButton("修改");
JButton b4=new JButton("增加");
JButton b5=new JButton("删除");



JTextArea t3=new JTextArea(150,150);
cp.add(j2);
j2.setBounds(220,110,190,25);
cp.add(j1);
j1.setBounds(220,150,190,25);
cp.add(b1);
b1.setBounds(0, 70, 90, 25);
cp.add(b2);
b2.setBounds(250, 250, 70, 25);
cp.add(b4);
b4.setBounds(0,110,90,25);
cp.add(b3);
b3.setBounds(0,150,90,25);
cp.add(b5);
b5.setBounds(0,190,90,25);
//给这几个安排位置


b1.addActionListener(new ActionListener() {
	
	
	private void closeThis() {
		// TODO Auto-generated method stub
		
	}
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		closeThis();
		new Select();
		//进入到新界面 UIzhuec
	
}
});


b2.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
// TODO 自动生成的方法存根
	 if(e.getActionCommand().equals("取消")){
System.exit(0);
        }
}
});
b3.addActionListener(new ActionListener() {
	
	
	private void closeThis() {
		// TODO Auto-generated method stub
		
	}
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		closeThis();
		new Revise();
		//进入到新界面 UIzhuec
	
}
});
b4.addActionListener(new ActionListener() {
	
	
	private void closeThis() {
		// TODO Auto-generated method stub
		
	}
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		closeThis();
		new Add("企业添加");
		//进入到新界面 UIzhuec
	
}
});
b5.addActionListener(new ActionListener() {
	
	
	private void closeThis() {
		// TODO Auto-generated method stub
		
	}
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		closeThis();
		new Delete();
		//进入到新界面 UIzhuec
	
}
});

	 }

	 public static void main(String[] args) {
	      new Main();

	   }
}
