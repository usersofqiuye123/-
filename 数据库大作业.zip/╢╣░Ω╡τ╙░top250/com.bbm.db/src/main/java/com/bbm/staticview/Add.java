package com.bbm.staticview;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import com.bbm.db.stocksinvestDao;

public class Add extends JFrame {
   private JPanel panel,moviePanel,btnPanel;
   private JLabel ranking,CName,comment,
   fName,grade,brief;
   private JTextField txtranking,txtCName,txtcomment,
   txtfName,txtgrade,txtbrief;
   JComboBox cmbBookType;//组合框
   private JButton btnAdd,btnReset,btnExit;
   public Add(String s)
   {
      super(s);
      setSize(400,200);//框的长宽
      setLocationRelativeTo(null);
      panel=new JPanel(new BorderLayout());
      setContentPane(panel);
      //影片面板的信息
      GridLayout grid1=new GridLayout(3,3);//网格布局（采用指定的行数列数）
      grid1.setHgap(20);//组件之间的水平间距
      grid1.setVgap(20);//组件之间的垂直间距
      moviePanel=new JPanel(grid1);
      ranking=new JLabel("股票编码:");
      ranking.setHorizontalAlignment(SwingConstants.CENTER);//居中
      txtranking=new JTextField(15);//JTextField是文本框，用来编辑单行文本，用来计算首选宽度的列数；
    final String rank=txtranking.getText();
    
      CName=new JLabel("企业名：");
      txtCName=new JTextField(12);
      final String chname=txtCName.getText();
      
      comment=new JLabel("评价:");
      txtcomment=new JTextField(12);
      final String commentNume=txtranking.getText();
      
      fName=new JLabel("评价机构:");
      txtfName=new JTextField();
      final String foname=txtranking.getText();
      
      grade=new JLabel("日期:");
      txtgrade=new JTextField(12);
      final String commentGrade=txtgrade.getText();
      
      brief=new JLabel("评价师:");
      txtbrief=new JTextField(12);
      final String introduction=txtbrief.getText();
      
      moviePanel.add(ranking);
      moviePanel.add(txtranking);
    

      moviePanel.add(CName);
      moviePanel.add(txtCName);
      moviePanel.add(comment);
      moviePanel.add(txtcomment);
      moviePanel.add(fName);
      moviePanel.add(txtfName);
      moviePanel.add(grade);
      moviePanel.add(txtgrade);
      moviePanel.add(brief);
      moviePanel.add(txtbrief);
      //将各组件加入到面板
      panel.add(moviePanel,BorderLayout.CENTER);
      btnPanel=new JPanel();
      btnAdd=new JButton("增加");
      btnReset=new JButton("重置");
      btnExit=new JButton("退出");
      btnPanel.add(btnAdd);
      btnPanel.add(btnReset);
      btnPanel.add(btnExit);
      panel.add(btnPanel,BorderLayout.SOUTH);       
      
      setVisible(true);     
      btnAdd.addActionListener(new ActionListener() {
  		
  		
  		private void closeThis() {
  			// TODO Auto-generated method stub
  			
  		}
  		public void actionPerformed(ActionEvent e) {
  			// TODO Auto-generated method stub
  			if(e.getActionCommand().equals("增加")){
  				new stocksinvestDao();
  				System.out.print("增加成功！");
  				
  		  		         }
  			closeThis();
  		
  		
  			
  			//进入到新界面 UIzhuec
  		
  	}
  	});

  	btnExit.addActionListener(new ActionListener() {
  		 public void actionPerformed(ActionEvent e) {
  	// TODO 自动生成的方法存根
  			 if(e.getActionCommand().equals("退出")){
  	   System.exit(0);
  		         }
  	  }
  	 });}
   public static void main(String[] args) {
      new Add("企业添加");

   }

}
