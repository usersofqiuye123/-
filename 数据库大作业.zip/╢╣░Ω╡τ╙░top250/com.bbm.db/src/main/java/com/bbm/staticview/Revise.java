package com.bbm.staticview;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.bbm.db.stocksinvestDao;

public class Revise extends JFrame{
	
	 private JPanel panel,moviePanel,btnPanel;
	   private JLabel ranking,CName,comment,
	   fName,grade,brief;
	   private JTextField txtranking,txtCName,txtcomment,
	   txtfName,txtgrade,txtbrief;
	   JComboBox cmbBookType;//组合框
	   private JButton btnAdd,btnReset,btnExit;
	
	public Revise () {
		 setTitle("修改");
	      setSize(400,200);//框的长宽
	      setLocationRelativeTo(null);
	      panel=new JPanel(new BorderLayout());
	      setContentPane(panel);
	      //影片面板的信息
	      GridLayout grid1=new GridLayout(3,3);//网格布局（采用指定的行数列数）
	      grid1.setHgap(20);//组件之间的水平间距
	      grid1.setVgap(20);//组件之间的垂直间距
	      moviePanel=new JPanel(grid1);
	      ranking=new JLabel("新的股票编码:");
	      ranking.setHorizontalAlignment(SwingConstants.CENTER);//居中
	      txtranking=new JTextField(15);//JTextField是文本框，用来编辑单行文本，用来计算首选宽度的列数；
	    
	      CName=new JLabel("新的企业名：");
	      txtCName=new JTextField(12);
	      comment=new JLabel("新的评价:");
	      txtcomment=new JTextField(12);
	      fName=new JLabel("新的评价机构:");
	      txtfName=new JTextField();
	      grade=new JLabel("新的日期:");
	      txtgrade=new JTextField(12);
	      brief=new JLabel("新的评价师:");
	      txtbrief=new JTextField(12);
	     
	      moviePanel.add(ranking);
	      moviePanel.add(txtranking);
	    

	      moviePanel.add(CName);
	      moviePanel.add(txtCName);
	      moviePanel.add(comment);
	      moviePanel.add(txtcomment);
	      moviePanel.add(fName);
	      moviePanel.add(txtfName);
	      moviePanel.add(grade);
	      moviePanel.add(txtgrade);
	      moviePanel.add(brief);
	      moviePanel.add(txtbrief);
	      //将各组件加入到面板
	      panel.add(moviePanel,BorderLayout.CENTER);
	      btnPanel=new JPanel();
	      btnAdd=new JButton("修改");
	      btnReset=new JButton("重置");
	      btnExit=new JButton("退出");
	      btnPanel.add(btnAdd);
	      btnPanel.add(btnReset);
	      btnPanel.add(btnExit);
	      panel.add(btnPanel,BorderLayout.SOUTH);       
	      
	      setVisible(true); 
	
	btnAdd.addActionListener(new ActionListener() {
		
		
		private void closeThis() {
			// TODO Auto-generated method stub
			
		}
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if(e.getActionCommand().equals("修改")){
				  
					new stocksinvestDao();
					int r=stocksinvestDao.update(null);
					System.out.print("修改成功！");
					
					//进入到新界面 UIzhuec
					         }

			closeThis();
		
	}
	});
	btnExit.addActionListener(new ActionListener() {
		 public void actionPerformed(ActionEvent e) {
	// TODO 自动生成的方法存根
			 if(e.getActionCommand().equals("取消")){
	   System.exit(0);
		         }
	  }
	 });}
	


	public static void main(String[] args) {
		// TODO Auto-generated method stub
new Revise();
	}

}
