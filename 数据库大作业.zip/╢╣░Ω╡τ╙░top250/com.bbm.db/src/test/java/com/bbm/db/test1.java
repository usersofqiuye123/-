package com.bbm.db;

import static org.junit.Assert.*;

import org.junit.Test;

public class test1 {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
